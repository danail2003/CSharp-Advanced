﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Name = "Pesho";
            person.Age = 20;
            Person person1 = new Person();
            person1.Name = "Gosho";
            person1.Age = 18;
            Person person2 = new Person();
            person2.Name = "Stamat";
            person2.Age = 43;
        }
    }
}
